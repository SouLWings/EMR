<?php
mysql_connect("mysql6.000webhost.com","a7718353_doctor","doctor123");
mysql_select_db("a7718353_emr");
?>