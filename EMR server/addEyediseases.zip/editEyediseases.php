<?php
if(isset($_POST['eyedisease']) && !empty($_POST['eyedisease']) && isset($_POST['id']) && !empty($_POST['id'])){
	$con = new mysqli("mysql6.000webhost.com", "a7718353_doctor", "doctor123", "a7718353_emr");
	$id = $_POST['id'];
	$eyedisease = $_POST['eyedisease'];
	$description = $_POST['etdescription'];
	if($con->query("UPDATE `eyedisease` SET `eyedisease`='$eyedisease', `description`='$description' WHERE `id`=$id"))
	{
		echo 'success';
	}
	else{
		echo 'error';
	}
	$con->close();
}
else
	echo 'error';
?>
