<?php
if(isset($_POST['labtest']) && !empty($_POST['labtest']) && isset($_POST['id']) && !empty($_POST['id'])){
	$con = new mysqli("mysql6.000webhost.com", "a7718353_doctor", "doctor123", "a7718353_emr");
	$id = $_POST['id'];
	$appointmentdate = $_POST['appointmentdate'];
	$labtest = $_POST['labtest'];
	$surgery = $_POST['surgery'];
	$medcine = $_POST['medcine'];
	if($con->query("UPDATE `patient_orders` SET `labtest`='$labtest', `surgery`='$surgery', `medcine`='$medcine', `appointmentdate`='$appointmentdate' WHERE `id` = $id"))
	{
		echo 'success';
	}
	else{
		echo 'error';
	}
	$con->close();
}
else
	echo 'error';
?>
